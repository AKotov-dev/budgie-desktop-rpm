unit Unit1;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, ExtCtrls, StdCtrls,
  Buttons, ComCtrls, Process, DefaultTranslator;

type

  { TMainForm }

  TMainForm = class(TForm)
    BitBtn1: TBitBtn;
    BitBtn2: TBitBtn;
    Edit1: TEdit;
    Label1: TLabel;
    Label2: TLabel;
    OpenDialog1: TOpenDialog;
    RadioGroup1: TRadioGroup;
    SpeedButton1: TSpeedButton;
    procedure BitBtn1Click(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure FormShow(Sender: TObject);
    procedure RadioGroup1SelectionChanged(Sender: TObject);
    procedure SpeedButton1Click(Sender: TObject);
  private

  public

  end;

var
  MainForm: TMainForm;

implementation

{$R *.lfm}

{ TMainForm }


//Читаем Стиль = Позиция Items
procedure TMainForm.FormShow(Sender: TObject);
var
  S: ansistring;
begin
  //Считываем стиль картинки
  if RunCommand('/bin/bash', ['-c',
    'gsettings get org.gnome.desktop.background picture-options | tr -d "\"" | tr -d "\'
    +
    '''' + '"'], S) then
    S := Trim(S);

  case S of
    'none': RadioGroup1.ItemIndex := 0;
    'wallpaper': RadioGroup1.ItemIndex := 1;
    'centered': RadioGroup1.ItemIndex := 2;
    'scaled': RadioGroup1.ItemIndex := 3;
    'stretched': RadioGroup1.ItemIndex := 4;
    'zoom': RadioGroup1.ItemIndex := 5;
    'spanned': RadioGroup1.ItemIndex := 6;
  end;

  //Считываем путь к картинке
  if RunCommand('/bin/bash', ['-c',
    'gsettings get org.gnome.desktop.background picture-uri | tr -d "\"" | tr -d "\' +
    '''' + '"'], S) then
    Edit1.Text := Trim(S);
end;

//Стиль картинки фона
procedure TMainForm.RadioGroup1SelectionChanged(Sender: TObject);
var
  S: ansistring;
begin
  //Изменяем стиль картинки
  RunCommand('/bin/bash', ['-c',
    'gsettings set org.gnome.desktop.background picture-options ' +
    RadioGroup1.Items[RadioGroup1.ItemIndex]], S);
end;

//Выбор фона Рабочего стола
procedure TMainForm.SpeedButton1Click(Sender: TObject);
var
  S: ansistring;
begin
  if OpenDialog1.Execute then
  begin
    Edit1.Text := 'file://' + OpenDialog1.FileName;
    RunCommand('/bin/bash', ['-c',
      'gsettings set org.gnome.desktop.background picture-uri ' +
      '''' + Edit1.Text + ''''], S);
  end;
end;

procedure TMainForm.FormCreate(Sender: TObject);
begin
  MainForm.Caption := Application.Title;
end;

procedure TMainForm.BitBtn1Click(Sender: TObject);
var
  S: ansistring;
begin
  Screen.Cursor := crHourGlass;
  Application.ProcessMessages;

  //#--Настрока labwc (Budgie-10.10.3 / Wayland)
  if LowerCase(GetEnvironmentVariable('XDG_SESSION_TYPE')) = 'wayland' then
  begin
    ForceDirectories(GetUserDir + '.config/budgie-desktop/labwc');
    RunCommand('/bin/bash', ['-c',
      'cp -f ./labwc/{autostart,rc.xml} ~/.config/budgie-desktop/labwc/'], S);
  end;

  //#---Опции клавы---
  RunCommand('/bin/bash', ['-c',
    'gsettings set org.gnome.desktop.input-sources xkb-options "[' +
    '''' + 'grp:ctrl_shift_toggle' + '''' + ', ' + '''' + 'grp_led:scroll' +
    '''' + ', ' + '''' + 'compose:rwin' + '''' + ']"'], S);

  RunCommand('/bin/bash', ['-c',
    'gsettings set org.gnome.desktop.input-sources show-all-sources false'], S);

  RunCommand('/bin/bash', ['-c',
    'gsettings set org.gnome.desktop.input-sources mru-sources "[]"'], S);

  //#[Alt+Shift]
  RunCommand('/bin/bash', ['-c',
    'gsettings set org.gnome.desktop.wm.keybindings switch-input-source "[' +
    '''' + '<Alt>Shift_L' + '''' + ']"'], S);

  RunCommand('/bin/bash', ['-c',
    'gsettings set org.gnome.desktop.wm.keybindings switch-input-source-backward "[' +
    '''' + '<Shift>Alt_L' + '''' + ']"'], S);

  //#---Размер и шрифт рабочего стола под юзером---
  RunCommand('/bin/bash', ['-c', 'gsettings set org.nemo.desktop font ' +
    '''' + 'Cantarell Regular 10' + ''''], S);

  //#---Не показывать смонтированное на десктопе---
  RunCommand('/bin/bash', ['-c',
    'gsettings set org.nemo.desktop volumes-visible false'], S);

  //#---Масштаб иконок = 66%---
  RunCommand('/bin/bash', ['-c',
    'gsettings set org.nemo.icon-view default-zoom-level small'], S);

  //#---Компактный вид = 66%---
  RunCommand('/bin/bash', ['-c',
    'gsettings set org.nemo.compact-view default-zoom-level small'], S);

  //#---Просматривать исполняемые текстовые файлы---
  RunCommand('/bin/bash', ['-c',
    'gsettings set org.nemo.preferences executable-text-activation display'], S);

  //#---Удалять клавишей Delete---
  RunCommand('/bin/bash', ['-c',
    'gsettings set org.nemo.preferences swap-trash-delete true'], S);

  //#---Переименовывать двойным медленным нажатием---
  RunCommand('/bin/bash', ['-c',
    'gsettings set org.nemo.preferences quick-renames-with-pause-in-between true'], S);

  //#--- ~/Рабочий стол = ~/Desktop под юзером ---
  RunCommand('/bin/bash', ['-c',
    '[ ! -L ~/Desktop ] && ln -s ~/Рабочий\ стол/ ~/Desktop'], S);

  //#--- Включить меню терминала Gnome постоянно (под юзером) ---
  RunCommand('/bin/bash', ['-c',
    'gsettings set org.gnome.Terminal.Legacy.Settings headerbar ' +
    '''' + 'false' + ''''], S);

  //#--- Выключить комбинации клавиш терминала Gnome ---
  RunCommand('/bin/bash', ['-c',
    'gsettings set org.gnome.Terminal.Legacy.Settings shortcuts-enabled ' +
    '''' + 'false' + ''''], S);

  //#--- Отключить подтверждение при выходе из терминала ---
  RunCommand('/bin/bash', ['-c',
    'gsettings set org.gnome.Terminal.Legacy.Settings confirm-close ' +
    '''' + 'false' + ''''], S);

  //#---Отключить F10 (для выхода из mc)--
  RunCommand('/bin/bash', ['-c',
    'gsettings set org.gnome.Terminal.Legacy.Settings menu-accelerator-enabled false'], S);

  //#--- Кодировка Windows-1251 в текстовом редакторе xed (под юзером) ---
  RunCommand('/bin/bash', ['-c',
    'gsettings set org.x.editor.preferences.encodings auto-detected "[' +
    '''' + 'UTF-8' + '''' + ', ' + '''' + 'WINDOWS-1251' + '''' +
    ', ' + '''' + 'KOI8-R' + '''' + ', ' + '''' + 'CP866' + '''' +
    ', ' + '''' + 'CURRENT' + '''' + ', ' + '''' + 'ISO-8859-15' +
    '''' + ', ' + '''' + 'UTF-16' + '''' + ']"'], S);

  //#--- Контекстное меню + "Создать ссылку"---
  RunCommand('/bin/bash', ['-c',
    'gsettings set org.nemo.preferences.menu-config selection-menu-make-link true'], S);

  //#--- Отключение ScreenSaver ---
  RunCommand('/bin/bash', ['-c',
    'gsettings set org.gnome.desktop.session idle-delay ' + '''' + '0' + ''''], S);

  RunCommand('/bin/bash', ['-c',
    'gsettings set org.gnome.desktop.screensaver lock-delay ' + '''' + '0' + ''''], S);

  RunCommand('/bin/bash', ['-c',
    'gsettings set org.gnome.desktop.screensaver idle-activation-enabled ' +
    '''' + 'false' + ''''], S);

  RunCommand('/bin/bash', ['-c',
    'gsettings set org.gnome.desktop.screensaver lock-enabled ' +
    '''' + 'false' + ''''], S);

  //Nemo вместо Nautilus https://itsfoss.com/install-nemo-file-manager-ubuntu/
  RunCommand('/bin/bash', ['-c',
    'xdg-mime default nemo.desktop inode/directory application/x-gnome-saved-search'], S);
  //Отключить Nautilus
  RunCommand('/bin/bash', ['-c',
    'gsettings set org.gnome.desktop.background show-desktop-icons false'], S);
  //Включить Nemo
  RunCommand('/bin/bash', ['-c',
    'gsettings set org.nemo.desktop show-desktop-icons true; nemo -q'], S);

  //networkmanager-applet: enable applet, disable notifications
  //https://forum.ubuntu.ru/index.php?topic=275072.0
  RunCommand('/bin/bash', ['-c',
    'gsettings set org.gnome.nm-applet show-applet true'], S);
  RunCommand('/bin/bash', ['-c',
    'gsettings set org.gnome.nm-applet disable-vpn-notifications true'], S);
  RunCommand('/bin/bash', ['-c',
    'gsettings set org.gnome.nm-applet disable-connected-notifications true'], S);
  RunCommand('/bin/bash', ['-c',
    'gsettings set org.gnome.nm-applet disable-disconnected-notifications true'], S);

  //Кнопка питания (suspend — режим ожидания, interactive — спрашивать, что делать, nothing — ничего не делать,
  //hibernate — гибернация (если поддерживается), shutdown — выключение
  RunCommand('/bin/bash', ['-c',
    'gsettings set org.gnome.settings-daemon.plugins.power power-button-action ' +
    '''' + 'suspend' + ''''], S);

  Screen.Cursor := crDefault;
end;

end.
