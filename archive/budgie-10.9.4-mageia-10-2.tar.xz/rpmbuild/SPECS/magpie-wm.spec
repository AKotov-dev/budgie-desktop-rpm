%global debug_package %{nil}
%global magpie_abi_version magpie-0
%global __requires_exclude ^devel\\(libmagpie-.*\\)

Name:          magpie-wm
Version:       0.9.4
Release:       9.mrx10
Summary:       Window manager for Budgie Desktop

License:       GPL-2.0-or-later
URL:           https://github.com/BuddiesOfBudgie/magpie
Source0:       %{url}/releases/download/v%{version}/%{name}-%{version}.tar.xz

BuildRequires: pkgconfig(gobject-introspection-1.0) >= 1.41.0
BuildRequires: pkgconfig(sm)
BuildRequires: pkgconfig(libwacom)
BuildRequires: pkgconfig(x11)
BuildRequires: pkgconfig(xdamage)
BuildRequires: pkgconfig(xext)
BuildRequires: pkgconfig(xfixes)
BuildRequires: pkgconfig(xi)
BuildRequires: pkgconfig(xrandr)
BuildRequires: pkgconfig(xrender)
BuildRequires: pkgconfig(xcursor)
BuildRequires: pkgconfig(xcomposite)
BuildRequires: pkgconfig(x11-xcb)
BuildRequires: pkgconfig(xkbcommon)
BuildRequires: pkgconfig(xkbcommon-x11)
BuildRequires: pkgconfig(xkbfile)
BuildRequires: pkgconfig(xtst)
BuildRequires: mesaegl-devel
BuildRequires: mesaglesv1-devel
BuildRequires: mesagl-devel
BuildRequires: pkgconfig(gbm)
BuildRequires: pkgconfig(glesv2)
BuildRequires: pkgconfig(graphene-gobject-1.0)
BuildRequires: pam-devel
BuildRequires: pipewire-devel
BuildRequires: pkgconfig(sysprof-capture-4)
BuildRequires: sysprof-devel
BuildRequires: pkgconfig(libsystemd)
BuildRequires: x11-server-xorg
BuildRequires: x11-server-xvfb
BuildRequires: pkgconfig(xkeyboard-config)
BuildRequires: zenity
BuildRequires: desktop-file-utils
# Bootstrap requirements
BuildRequires: gtk-doc gettext-devel
BuildRequires: pkgconfig(libcanberra)
BuildRequires: pkgconfig(gsettings-desktop-schemas)
BuildRequires: pkgconfig(gnome-settings-daemon)
BuildRequires: cvt
BuildRequires: meson
BuildRequires: pkgconfig(gbm)
BuildRequires: pkgconfig(gnome-desktop-3.0)
BuildRequires: pkgconfig(gudev-1.0)
BuildRequires: pkgconfig(libdrm)
BuildRequires: pkgconfig(lcms2)
BuildRequires: pkgconfig(colord)

BuildRequires: pkgconfig(json-glib-1.0)
BuildRequires: pkgconfig(libinput)
BuildRequires: git
BuildRequires: pkgconfig(libstartup-notification-1.0)

Requires: gsettings-desktop-schemas
Requires: gnome-settings-daemon
Requires: gtk+3.0
Requires: json-glib
Requires: lib64input10
Requires: pipewire
Requires: dbus
Requires: zenity
Requires: mutter

Recommends: mesa-dri-drivers%{?_isa}

%description
Magpie is the window manager used by Budgie Desktop.


%package devel
Summary: Development package for %{name}

%description devel
Header files and libraries for developing against Magpie.

%prep
%autosetup -S git

%build
%meson -Degl_device=true
%meson_build

%install
%meson_install


%files
%license COPYING
%{_datadir}/locale/
%{_libdir}/lib%{magpie_abi_version}.so.0
%{_libdir}/lib%{magpie_abi_version}.so.0.0.0
%{_libdir}/%{magpie_abi_version}/Cally-0.*
%{_libdir}/%{magpie_abi_version}/Clutter-0.*
%{_libdir}/%{magpie_abi_version}/Cogl-0.*
%{_libdir}/%{magpie_abi_version}/CoglPango-0.*
%{_libdir}/%{magpie_abi_version}/Meta-0.*
%{_libdir}/%{magpie_abi_version}/libmagpie-clutter-0.*
%{_libdir}/%{magpie_abi_version}/libmagpie-cogl-0.*
%{_libdir}/%{magpie_abi_version}/libmagpie-cogl-pango-0.*

%files devel
%{_includedir}/%{magpie_abi_version}
%{_libdir}/lib%{magpie_abi_version}.so
%{_libdir}/pkgconfig/lib%{magpie_abi_version}.pc
%{_libdir}/pkgconfig/magpie-clutter-0.pc
%{_libdir}/pkgconfig/magpie-cogl-0.pc
%{_libdir}/pkgconfig/magpie-cogl-pango-0.pc

%changelog
* Fri Apr 10 2026 AKotov-dev <alex_q_2000> 0.9.4-9.mrx10
- Release for Mageia-10

* Fri Jan 16 2026 Fedora Release Engineering <releng@fedoraproject.org> - 0.9.3-6
- Rebuilt for https://fedoraproject.org/wiki/Fedora_44_Mass_Rebuild

* Thu Jul 24 2025 Fedora Release Engineering <releng@fedoraproject.org> - 0.9.3-5
- Rebuilt for https://fedoraproject.org/wiki/Fedora_43_Mass_Rebuild

* Fri Jan 24 2025 Joshua Strobl <me@joshuastrobl.com> - 0.9.3-4
- Fix FTBFS due to missing build deps (cvt) #2340810

* Fri Jan 17 2025 Fedora Release Engineering <releng@fedoraproject.org> - 0.9.3-3
- Rebuilt for https://fedoraproject.org/wiki/Fedora_42_Mass_Rebuild

* Thu Sep 26 2024 Joshua Strobl <me@joshuastrobl.com> - 0.9.3-2
- Added patch to support X11 scaling changes in newest GNOME Settings Daemon

* Tue Sep 17 2024 Joshua Strobl <me@joshuastrobl.com> - 0.9.3-1
- Update to 0.9.3 and add patch for gnome-settings-daemon breakage

* Thu Jul 18 2024 Fedora Release Engineering <releng@fedoraproject.org> - 0.9.2-4
- Rebuilt for https://fedoraproject.org/wiki/Fedora_41_Mass_Rebuild

* Thu Jan 25 2024 Fedora Release Engineering <releng@fedoraproject.org> - 0.9.2-3
- Rebuilt for https://fedoraproject.org/wiki/Fedora_40_Mass_Rebuild

* Sun Jan 21 2024 Fedora Release Engineering <releng@fedoraproject.org> - 0.9.2-2
- Rebuilt for https://fedoraproject.org/wiki/Fedora_40_Mass_Rebuild

* Sun Aug 20 2023 Joshua Strobl <me@joshuastrobl.com> - 0.9.2-1
- Initial inclusion of magpie
