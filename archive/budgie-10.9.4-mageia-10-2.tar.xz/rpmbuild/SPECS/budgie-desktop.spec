%global debug_package %{nil}

Name:    budgie-desktop
Version: 10.9.4
Release: 3.mrx10
Packager: <AKotov-dev>
License: GPLv2 and LGPLv2.1
Summary: An elegant desktop with GNOME integration
URL:     https://github.com/BuddiesOfBudgie/budgie-desktop

Source: budgie-desktop-v%{version}.tar.xz

# Keyboard layout ['<Shift>Alt_L']
# Source1: 20_solus-project.budgie.wm.gschema.override

BuildRequires: sassc
BuildRequires: peas-devel
BuildRequires: libmutter-devel
BuildRequires: pkgconfig(gnome-desktop-3.0)
BuildRequires: pkgconfig(gnome-bluetooth-1.0)
BuildRequires: pkgconfig(accountsservice)
BuildRequires: pkgconfig(x11)
BuildRequires: pkgconfig(vapigen)
BuildRequires: pkgconfig(ibus-1.0)
BuildRequires: pkgconfig(gnome-settings-daemon)
BuildRequires: pkgconfig(libwnck-3.0)
BuildRequires: pkgconfig(libpulse)
BuildRequires: pkgconfig(alsa)
BuildRequires: pkgconfig(gtk+-3.0)
BuildRequires: pkgconfig(polkit-gobject-1)
BuildRequires: pkgconfig(libgnome-menu-3.0)
BuildRequires: pkgconfig(upower-glib) >= 1.90.0
BuildRequires: pkgconfig(libxfce4windowing-0) >= 4.19.3

BuildRequires: meson
BuildRequires: cmake
BuildRequires: intltool
BuildRequires: gtk-doc
BuildRequires: desktop-file-utils
# Для *.mrx8
BuildRequires: mesaegl-devel
BuildRequires: locales-en
# v10.6.4
BuildRequires: pkgconfig(gee-0.8)
#BuildRequires: budgie-screensaver
# v10.7.1
BuildRequires: pkgconfig(gstreamer-1.0)
#BuildRequires: magpie-wm-devel
#BuildRequires: libmagpie-0.so()(64bit)

Requires: magpie-wm
Requires: mutter
Requires: gtk+3.0
Requires: task-x11
Requires: dbus-x11
Requires: libwnck3
Requires: hicolor-icon-theme
# Requires: gnome-session
# v10.9.1
Requires: budgie-session
Requires: gnome-bluetooth
Requires: typelib(Peas)
Requires: typelib(Graphene)
Requires: typelib(GMenu)
Requires: task-pulseaudio
# v10.9.2
Requires: upower >= 1.90.0
Requires: lib64xfce4windowing0_0 >= 4.19.3
#nemo-desktop not start after upgrade without xapps
Requires: xapps
# v10.6.4
Requires: budgie-screensaver
# For Nemo v6.6.3
Recommends: xapp-symbolic-icons

#MgaRemix (nautilus -> nemo for desktop icons)
Recommends: nemo
Recommends: nemo-emblems
Recommends: nemo-fileroller
Recommends: file-roller

# MgaRemix other Recommends packages
#Recommends: gnome-tweaks - тянет за собой gmome-shell, gdm и кучу ненужных либ
Recommends: dconf-editor
Recommends: gnome-disk-utility
Recommends: gnome-calculator
# v10.7.1
#Recommends: gnome-screenshot
Recommends: gnome-terminal

Recommends: mc
# Will already be installed in ICEWM
Recommends: lxdm
# v10.8; Transition to NetworkManager and Budgie Control Center
Recommends: networkmanager networkmanager-applet

Recommends: xed
Recommends: mtools
Recommends: xrandr

# like task-kde4, but suggests instead of requires
Recommends: task-codec-audio
Recommends: task-codec-video

Requires(post): /sbin/ldconfig
Requires(postun): /sbin/ldconfig

Requires: %{name}-libs
Requires: %{name}-plugins-core
Requires: %{name}-schemas
Requires: %{name}-rundialog

%description
Budgie is the flagship desktop of the Solus, and is an Solus project.
The Budgie Desktop a modern desktop designed to keep out the way of
the user. It features heavy integration with the GNOME stack in order
for an enhanced experience.

%package        plugins-core
Summary:        Core plugins for the Budgie Desktop
#MgaRemix
Requires:       gtk+3.0
Requires:       %{name}-libs%{?_isa} = %{version}-%{release}
Requires:       %{name}-schemas%{?_isa} = %{version}-%{release}

%description    plugins-core
This package contains the core plugins of Budgie Desktop.

%package        rundialog
Summary:        Budgie Run Dialog for the Budgie Desktop
Requires:       %{name}-libs%{?_isa} = %{version}-%{release}
Requires:       %{name}-schemas%{?_isa} = %{version}-%{release}

%description    rundialog
Budgie Run Dialog for the Budgie Desktop

%package        libs
#MgaRemix
Summary:        Common libs for the Budgie Desktop
Requires:       gtk+3.0
AutoReq:	no

Requires(post): /sbin/ldconfig
Requires(postun): /sbin/ldconfig

%description    libs
This package contains the shared library of Budgie Desktop.

%package        schemas
Summary:        GLib schemas for the Budgie Desktop

%description    schemas
GLib schemas for the Budgie Desktop

%package        docs
Summary:        GTK3 Desktop Environment -- Documentation files
Group:          Documentation/HTML

%description    docs
GTK3 Desktop Environment -- Documentation files.
This package provides API Documentation for the Budgie Plugin API, in the
GTK-Doc HTML format.

%package        devel
Summary:        Development files for the Budgie Desktop
Requires:       %{name}%{?_isa} = %{version}-%{release}

%description    devel
This package contains the files required for developing for Budgie Desktop.

%prep
%setup -q -T -b 0 -n %{name}-%{version}
# Keyboard layout ['<Shift>Alt_L']
# cp -f %{SOURCE1} %{_builddir}/%{name}-%{version}/src/wm/

%build
export LC_ALL=en_US.utf8

#MgaRemix (without gnome-screensaver)
%meson --prefix=%{_prefix} --libdir=%{_libdir}

%meson_build

%install
export LC_ALL=en_US.utf8

%meson_install
find %{buildroot} -name '*.la' -delete

%find_lang %{name}

%check
desktop-file-validate %{buildroot}/%{_datadir}/applications/*.desktop

# MgaRemix
%post
ldconfig
# GNOME menu link (v <= 10.6.4)
#if [ ! -L "/etc/xdg/menus/gnome-applications.menu" ]; then
#    cd /etc/xdg/menus
#    ln -s applications.menu gnome-applications.menu
#fi;

# XDG_CURRENT_DESKTOP (Budgie-10.9.4) for libproxy
echo '[ ${XDG_CURRENT_DESKTOP} = "Budgie" ] && export XDG_CURRENT_DESKTOP="Budgie:GNOME"' > /etc/profile.d/budgie-gnome.sh

# Nemo autostart shortcut
echo "[Desktop Entry]
Type=Application
Name=Nemo
Name[ru_RU]=budgie-nemo-autostart.desktop
Comment=Start Nemo desktop at log in
Exec=nemo-desktop
OnlyShowIn=Budgie;
NoDisplay=true" > /etc/xdg/autostart/budgie-nemo-autostart.desktop

# /etc/xdg/autostart/nm-applet.desktop
sed -i 's/^Exec=nm-applet.*/Exec=nm-applet --indicator/' /etc/xdg/autostart/nm-applet.desktop

%files -f %{name}.lang
%doc README.md
%license LICENSE LICENSE.LGPL2.1
%{_bindir}/budgie-*
%config(noreplace) %{_sysconfdir}/xdg/autostart/*.desktop
%{_datadir}/applications/*.desktop
%{_datadir}/gnome-session/sessions/*.session
%{_datadir}/icons/hicolor/scalable/apps/budgie-desktop-symbolic.svg
%{_datadir}/icons/hicolor/scalable/actions/notification-alert-symbolic.svg
%{_datadir}/icons/hicolor/scalable/actions/pane-hide-symbolic.svg
%{_datadir}/icons/hicolor/scalable/actions/pane-show-symbolic.svg
%{_datadir}/icons/hicolor/scalable/actions/system-hibernate-symbolic.svg
%{_datadir}/icons/hicolor/scalable/actions/system-log-out-symbolic.svg
%{_datadir}/icons/hicolor/scalable/actions/system-reboot-symbolic.svg
%{_datadir}/icons/hicolor/scalable/actions/system-suspend-symbolic.svg
%{_datadir}/icons/hicolor/scalable/apps/clock-applet-symbolic.svg
%{_datadir}/icons/hicolor/scalable/apps/icon-task-list-symbolic.svg
%{_datadir}/icons/hicolor/scalable/apps/notifications-applet-symbolic.svg
%{_datadir}/icons/hicolor/scalable/actions/notification-disabled-symbolic.svg
%{_datadir}/icons/hicolor/scalable/apps/separator-symbolic.svg
%{_datadir}/icons/hicolor/scalable/apps/spacer-symbolic.svg
%{_datadir}/icons/hicolor/scalable/apps/system-tray-symbolic.svg
%{_datadir}/icons/hicolor/scalable/apps/task-list-symbolic.svg
%{_datadir}/icons/hicolor/scalable/apps/workspace-switcher-symbolic.svg
%{_datadir}/icons/hicolor/scalable/apps/my-caffeine-on-symbolic.svg
%{_datadir}/icons/hicolor/scalable/status/budgie-caffeine-cup-empty.svg
%{_datadir}/icons/hicolor/scalable/status/budgie-caffeine-cup-full.svg
%{_datadir}/icons/hicolor/scalable/status/caps-lock-symbolic.svg
%{_datadir}/icons/hicolor/scalable/status/num-lock-symbolic.svg
%{_datadir}/xsessions/budgie-desktop.desktop
%{_datadir}/backgrounds/budgie/default.jpg
%{_datadir}/budgie/budgie-version.xml
# 10.7.1
%{_datadir}/icons/hicolor/scalable/actions/budgie-menu-symbolic.svg
%{_datadir}/icons/hicolor/scalable/apps/org.buddiesofbudgie.BudgieScreenshot.svg
%{_bindir}/org.buddiesofbudgie.BudgieScreenshot
%{_libexecdir}/budgie-desktop/budgie-polkit-dialog
%{_libexecdir}/budgie-desktop/budgie-power-dialog
%{_libexecdir}/bsd-backlight-helper
%{_libexecdir}/bsd-media-keys
%{_libexecdir}/bsd-power
%{_libexecdir}/bsd-wacom
%{_libexecdir}/bsd-wacom-oled-helper

%{_datadir}/gir-1.0/Budgie-2.0.gir
%{_datadir}/gir-1.0/BudgieRaven-2.0.gir
%{_datadir}/polkit-1/actions/org.buddiesofbudgie.settings-daemon.plugins.power.policy
%{_datadir}/polkit-1/actions/org.buddiesofbudgie.settings-daemon.plugins.wacom.policy
%{_datadir}/vala/vapi/budgie-2.0.deps
%{_datadir}/vala/vapi/budgie-2.0.vapi
%{_datadir}/vala/vapi/budgie-raven-plugin-2.0.deps
%{_datadir}/vala/vapi/budgie-raven-plugin-2.0.vapi

# 10.8.1
%{_datadir}/xdg-desktop-portal/budgie-portals.conf
# 10.9.1
%{_bindir}/org.buddiesofbudgie.sendto

%files plugins-core
%{_libdir}/budgie-desktop/*

%files schemas
%{_datadir}/glib-2.0/schemas/com.solus-project.*.gschema.xml
%{_datadir}/glib-2.0/schemas/20_solus-project.budgie.wm.gschema.override
# 10.7.1
%{_datadir}/glib-2.0/schemas/20_buddiesofbudgie.budgie-desktop.notifications.gschema.override
%{_datadir}/glib-2.0/schemas/org.buddiesofbudgie.budgie-desktop.raven.widget.Calendar.gschema.xml
%{_datadir}/glib-2.0/schemas/org.buddiesofbudgie.budgie-desktop.raven.widget.SoundOutput.gschema.xml
%{_datadir}/glib-2.0/schemas/org.buddiesofbudgie.budgie-desktop.raven.widget.UsageMonitor.gschema.xml
%{_datadir}/glib-2.0/schemas/org.buddiesofbudgie.budgie-desktop.screenshot.gschema.xml
%{_datadir}/glib-2.0/schemas/org.buddiesofbudgie.budgie-desktop.raven.widget.SoundInput.gschema.xml
%{_datadir}/glib-2.0/schemas/org.buddiesofbudgie.settings-daemon.plugins.media-keys.gschema.xml

%files libs
%{_libdir}/budgie-desktop/
%{_libdir}/libbudgietheme.so.0
%{_libdir}/libbudgietheme.so.0.0.0
%{_libdir}/libbudgie-plugin.so.0
%{_libdir}/libbudgie-plugin.so.0.0.0
%{_libdir}/libbudgie-private.so.0
%{_libdir}/libbudgie-private.so.0.0.0
%{_libdir}/libraven.so.0
%{_libdir}/libraven.so.0.0.0
%{_libdir}/girepository-1.0/Budgie*.typelib
# 10.7.1
%{_libdir}/libbudgie-appindexer.so
%{_libdir}/libbudgie-appindexer.so.0
%{_libdir}/libbudgie-appindexer.so.0.0.0
%{_libdir}/libbudgie-raven-plugin.so
%{_libdir}/libbudgie-raven-plugin.so.0
%{_libdir}/libbudgie-raven-plugin.so.0.0.0

%files rundialog
%{_bindir}/budgie-run-dialog

%files docs
%{_datadir}/gtk-doc/html/budgie-desktop/
%{_mandir}/man1/budgie-daemon.1.xz
%{_mandir}/man1/budgie-desktop-settings.1.xz
%{_mandir}/man1/budgie-desktop.1.xz
%{_mandir}/man1/budgie-panel.1.xz
%{_mandir}/man1/budgie-run-dialog.1.xz
%{_mandir}/man1/budgie-wm.1.xz
%{_mandir}/man1/org.buddiesofbudgie.BudgieScreenshot.1.xz
# 10.9.1
%{_mandir}/man1/org.buddiesofbudgie.sendto.1.xz

%files devel
%{_includedir}/budgie-desktop/
%{_includedir}/budgie-settings-daemon-48/
%{_libdir}/pkgconfig/budgie*.pc
%{_libdir}/libbudgietheme.so
%{_libdir}/libbudgie-plugin.so
%{_libdir}/libbudgie-private.so
%{_libdir}/libraven.so


%changelog
* Fri Apr 10 2026 AKotov-dev <alex_q_2000> 10.9.4-3.mrx10
- Release for Mageia-10

* Sat Jun 22 2024 AKotov-Dev <alex_q_2000> 10.9.2-2.mrx9
- Budgie 10.9.2 is the second minor release of Budgie 10.9 series of our Budgie Desktop environment

* Sun Apr 28 2024 AKotov-Dev <alex_q_2000> 10.9.1-1.mrx9
- v10.9.1; Transition to budgie-session

* Mon Oct 09 2023 AKotov-Dev <alex_q_2000> 10.8.1-1.mrx9
- v10.8; Transition to NetworkManager and Budgie Control Center
- after install nm-lite package required for net_applet and draknetcenter disable

* Sun Sep 03 2023 AKotov-Dev <alex_q_2000> 10.8-1.mrx9
- v10.8; Transition to NetworkManager and Budgie Control Center
- after install nm-lite package required for net_applet and draknetcenter disable

* Sat Aug 26 2023 AKotov-Dev <alex_q_2000> 10.8-0.mrx9
- Budgie 10.8 is a brand new release series for Budgie Desktop,
- featuring improvements to Budgie Menu, adoption of StatusNotifier support in System Tray,
- Magpie v0.x support, and more!
- Learn more at https://buddiesofbudgie.org/blog/budgie-10.8-released

* Sun May 21 2023 AKotov-Dev <alex_q_2000> 10.7.2-1.mrx9
- Added "AutoReqProv: no" to libs package (exclusion of unnecessary -devel packages)
- budgie-desktop with budgie-screensaver for Mageia-9
- Note: Before building budgie-desktop, the package budgie-screensaver is first assembled and installed

* Thu Apr 27 2023 AKotov-dev <alex_q_2000> 10.7.2-0.mga9
- budgie-desktop with budgie-screensaver for Mageia-9
- Note: Before building budgie-desktop, the package budgie-screensaver is first assembled and installed

* Thu Feb 23 2023 AKotov-dev <alex_q_2000> 10.7.1-0.mga9
- budgie-desktop with budgie-screensaver for Mageia-9
- Note: Before building budgie-desktop, the package budgie-screensaver is first assembled and installed

* Thu Dec 08 2022 AKotov-dev <alex_q_2000> 10.6.4-3.mga9
- budgie-desktop with budgie-screensaver for Mageia-9
- Note: Before building budgie-desktop, the package budgie-screensaver is first assembled and installed

* Sat Nov 05 2022 AKotov-dev <alex_q_2000> 10.6.4-2.mga9
- budgie-desktop with budgie-screensaver for Mageia-9
- Note: Before building budgie-desktop, the package budgie-screensaver is first assembled and installed

* Sun Sep 18 2022 AKotov-dev <alex_q_2000> 10.6.4-1.mga9
- budgie-desktop with budgie-screensaver for Mageia-9
- Note: Before building budgie-desktop, the package budgie-screensaver is first assembled and installed

* Thu Sep 08 2022 AKotov-dev <alex_q_2000> 10.6.4-0.mga9
- budgie-desktop for Mageia-9

* Sun Aug 21 2022 AKotov-dev <alex_q_2000> 10.6.3-0.mga9
- budgie-desktop for Mageia-9

* Sat Aug 20 2022 AKotov-dev <alex_q_2000> 10.6.2-0.mga9
- budgie-desktop for Mageia-9

* Mon Sep 09 2019 La Ode Muh. Fadlun Akbar <fadlun.net@gmail.com> - 20190909.67769ea-1
- build from commit 67769ea09299e57f3a4ceeb2223f642d86ecafcf
