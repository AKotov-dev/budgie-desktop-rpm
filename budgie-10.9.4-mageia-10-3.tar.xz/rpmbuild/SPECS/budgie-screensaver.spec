%global debug_package %{nil}

%global glib2_version 2.25
%global gnome_stack 3.1.91
%global gtk3_version 2.99.3

Name:           budgie-screensaver
Version:        5.1.0
Release:        11.mrx10
Summary:        A fork of gnome-screensaver intended for use with Budgie Desktop

License:        GPLv2
URL:            https://github.com/BuddiesOfBudgie/budgie-screensaver
Source0:  %{url}/releases/download/v%{version}/%{name}-v%{version}.tar.xz

BuildRequires:  pkgconfig(dbus-glib-1) >= 0.3.0
BuildRequires:  pkgconfig(gio-2.0) >= %{glib2_version}
BuildRequires:  pkgconfig(glib-2.0) >= %{glib2_version}
BuildRequires:  pkgconfig(gnome-desktop-3.0) >= %{gnome_stack}
BuildRequires:  pkgconfig(gsettings-desktop-schemas) >= %{gnome_stack}
BuildRequires:  pkgconfig(gthread-2.0) >= %{glib2_version}
BuildRequires:  pkgconfig(gtk+-3.0) >= %{gtk3_version}
BuildRequires:  pkgconfig(libsystemd)
BuildRequires:  pkgconfig(pam)
BuildRequires:  pkgconfig(x11) >= 1.0
BuildRequires:  desktop-file-utils
BuildRequires:  gcc
BuildRequires:  gettext
BuildRequires:  intltool
BuildRequires:  meson
BuildRequires:  pkgconfig(libgnomekbdui)
BuildRequires:  pkgconfig(xxf86vm)


%description
A fork of gnome-screensaver intended for use with Budgie Desktop.

%prep
%autosetup

%build
%meson
%meson_build

%install
%meson_install
%find_lang %{name}

%check
desktop-file-validate %{buildroot}%{_datadir}/applications/budgie-screensaver.desktop

%files -f %{name}.lang
%doc README.md
%license LICENSE
%{_bindir}/budgie-screensaver-command
%{_bindir}/budgie-screensaver
%{_datadir}/applications/budgie-screensaver.desktop
%{_libexecdir}/budgie-screensaver-dialog
%{_mandir}/man1/budgie-screensaver-command.1*
%{_mandir}/man1/budgie-screensaver.1*
%{_sysconfdir}/pam.d/budgie-screensaver

%changelog
* Tue Jun 16 2026 AKotov-dev <alex_q_2000> 5.1.0-11.mrx10
- Release for Mageia-10

* Fri Apr 10 2026 AKotov-dev <alex_q_2000> 5.1.0-10.mrx10
- Release for Mageia-10

* Thu Feb 23 2023 AKotov-dev <alex_q_2000> 5.1.0-4.mrx9
- budgie-screensaver for Mageia-9 (Budgie-10.7.1)

* Sat Dec 10 2022 AKotov-dev <alex_q_2000> 5.1.0-3.mrx9
- budgie-screensaver for Mageia-9

* Sat Nov 05 2022 AKotov-dev <alex_q_2000> 5.0.2-2.mrx9
- budgie-screensaver for Mageia-9

* Sun Sep 18 2022 AKotov-dev <alex_q_2000> 5.0.2-1.mrx9
- budgie-screensaver for Mageia-9

* Wed Jul 20 2022 Fedora Release Engineering <releng@fedoraproject.org> - 5.0.1-3
- Rebuilt for https://fedoraproject.org/wiki/Fedora_37_Mass_Rebuild

* Wed Jul 20 2022 Kalev Lember <klember@redhat.com> - 5.0.1-2
- Rebuilt for libgnome-desktop soname bump

* Sun May 15 2022 Joshua Strobl <me@joshuastrobl.com> - 5.0.1-1
- Initial packaging of budgie-screensaver
